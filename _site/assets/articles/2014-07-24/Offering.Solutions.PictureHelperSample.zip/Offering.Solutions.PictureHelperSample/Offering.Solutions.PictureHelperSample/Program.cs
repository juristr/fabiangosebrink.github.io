﻿using OfferingSolutions.PictureHelper;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;

namespace Offering.Solutions.PictureHelperSample
{
    class Program
    {
        static void Main(string[] args)
        {
            string directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string pathToImage = Path.Combine(directoryName, "BasicPicture.png");
            Image image = Image.FromFile(pathToImage);

            IOsPictureHelper osPictureHelper = new OsPictureHelper();

            // Changes the opacity of an image
            Image changeOpacity = osPictureHelper.ChangeOpacity(image, 50);

            // Crops the image with a given rectangle
            Image cropImage = osPictureHelper.CropImage(image, new Rectangle(20, 20, 100, 100));

            // Resizes the image using Size by keeping the ratio
            Image resizeImageWithSize = osPictureHelper.ResizeImage(image, new Size(50, 50));

            // Resizes the image using height and width by keeping the ratio
            Image resizeImageWithValues = osPictureHelper.ResizeImage(image, 50, 50);

            // Saves the image giving a guid as filename, returning the filename
            osPictureHelper.SaveImage(changeOpacity, directoryName);

            // Saves the image with the given filename
            osPictureHelper.SaveImage(cropImage, directoryName, "cropImage.png");

            // Saves the image with the given filename, converting it to jpg, returning the new filename
            osPictureHelper.SaveImage(resizeImageWithSize, directoryName, "resizeImageWithSize.png", ImageFormat.Jpeg);
        }
    }
}
