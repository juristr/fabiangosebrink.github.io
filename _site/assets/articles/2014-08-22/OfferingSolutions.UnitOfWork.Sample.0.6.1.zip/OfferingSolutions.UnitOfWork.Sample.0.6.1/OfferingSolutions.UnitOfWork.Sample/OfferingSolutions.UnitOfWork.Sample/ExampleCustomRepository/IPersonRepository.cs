﻿using OfferingSolutions.UnitOfWork.Sample.Models;
using OfferingSolutions.UoW.Structure.RepositoryContext;

namespace OfferingSolutions.UnitOfWork.Sample.ExampleCustomRepository
{
    public interface IPersonRepository : IRepositoryContext<Person>
    {
        void MyNewMethod(int id);
    }
}
