﻿using OfferingSolutions.UnitOfWork.Sample.Context;
using OfferingSolutions.UnitOfWork.Sample.Models;
using OfferingSolutions.UoW.Structure.RepositoryContext;

namespace OfferingSolutions.UnitOfWork.Sample.ExampleCustomRepository
{
    public class PersonRepository : RepositoryContextImpl<Person>, IPersonRepository
    {
        public PersonRepository(DatabaseContext context)
            : base(context)
        {

        }

        public void MyNewMethod(int id)
        {
            //do something
        }


    }
}
