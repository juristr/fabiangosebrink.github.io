﻿using System.Data.Entity;
using OfferingSolutions.UnitOfWork.Sample.Models;

namespace OfferingSolutions.UnitOfWork.Sample.Context
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext()
            : base("MyExampleDataBase")
        {

        }

        public DbSet<Person> Persons { get; set; }
        public DbSet<Thing> Things { get; set; }
    }
}
