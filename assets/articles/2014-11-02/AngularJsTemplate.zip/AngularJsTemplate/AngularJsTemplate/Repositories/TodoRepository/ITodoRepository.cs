﻿using AngularJsTemplate.Models;
using OfferingSolutions.UoW.Structure.RepositoryContext;

namespace AngularJsTemplate.Repositories.TodoRepository
{
    public interface ITodoRepository : IRepositoryContext<TodoItem>
    {
         
    }
}