﻿using System.Data.Entity;
using AngularJsTemplate.Models;
using OfferingSolutions.UoW.Structure.RepositoryContext;

namespace AngularJsTemplate.Repositories.TodoRepository.Impl
{
    public class TodoRepositoryImpl : RepositoryContextImpl<TodoItem>, ITodoRepository
    {
        public TodoRepositoryImpl(DbContext databaseContext) 
            : base(databaseContext)
        {
        }
    }
}