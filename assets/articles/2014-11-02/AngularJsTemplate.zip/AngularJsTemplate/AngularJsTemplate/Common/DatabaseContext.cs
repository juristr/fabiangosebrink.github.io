﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using AngularJsTemplate.Models;

namespace AngularJsTemplate.Common
{
    public class DatabaseContext : DbContext
    {
        public DbSet<TodoItem> TodoItems { get; set; }
    }
}