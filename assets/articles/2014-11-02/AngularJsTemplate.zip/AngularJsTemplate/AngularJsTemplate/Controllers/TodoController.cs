﻿using AngularJsTemplate.Common;
using AngularJsTemplate.Models;
using AngularJsTemplate.Repositories.TodoRepository;
using AngularJsTemplate.Repositories.TodoRepository.Impl;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace AngularJsTemplate.Controllers
{
    public class TodoController : ApiController
    {
        private readonly ITodoRepository _todoRepository;

        public TodoController()
        {
            _todoRepository = new TodoRepositoryImpl(new DatabaseContext());
        }

        [HttpPost]
        public void AddTodoItem(TodoItem todoItem)
        {
            using (_todoRepository)
            {
                todoItem.Added = DateTime.Now;
                _todoRepository.Add(todoItem);
                _todoRepository.Save();
            }
        }

        [HttpGet]
        public List<TodoItem> GetAllTodoItems()
        {
            using (_todoRepository)
            {
                return _todoRepository.GetAll();
            }
        }

        [HttpPost]
        public void RemoveTodoItem(TodoItem todoItem)
        {
            using (_todoRepository)
            {
                TodoItem findSingle = _todoRepository.FindSingle(todoItem.Id);

                if (findSingle != null)
                {
                    _todoRepository.Delete(todoItem.Id);
                    _todoRepository.Save();
                }
            }
        }
    }
}
