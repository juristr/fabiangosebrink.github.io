﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Security;
using Newtonsoft.Json.Linq;

namespace AngularJsTemplate.Controllers
{
    public class LoginController : ApiController
    {
        [HttpPost]
        public void DoLogin(JObject values)
        {
            string username = values["username"].ToString();
            string password = values["password"].ToString();
            //Check username and Password here against whatever
            FormsAuthentication.SetAuthCookie(username, true);
        }

        [HttpGet]
        public void DoLogout()
        {
            FormsAuthentication.SignOut();
        }
    }
}