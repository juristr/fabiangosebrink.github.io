﻿'use strict';
firstApp.factory('todoService', function ($http) {

    var todoService = {};

    var urlPrefix = '/api/Todo/';

    var _addTodo = function (todoName) {
        var data = { Name: todoName };
        var promise = $http.post(urlPrefix + 'AddTodoItem', data);
        return promise;
    };

    var _deleteTodo = function (item) {
        var promise = $http.post(urlPrefix + 'RemoveTodoItem', item);
        return promise;
    };
   
    var _getTodoItems = function () {
        var promise = $http.get(urlPrefix + 'GetAllTodoItems').then(function (results) {
            //console.log(results);
            return results.data;
        });
        return promise;
    };

    todoService.getTodoItems = _getTodoItems;
    todoService.addTodo = _addTodo;
    todoService.deleteTodo = _deleteTodo;

    return todoService;
});
