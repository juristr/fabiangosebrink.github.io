﻿firstApp.controller('homeController', function ($scope, $http) {
   
});