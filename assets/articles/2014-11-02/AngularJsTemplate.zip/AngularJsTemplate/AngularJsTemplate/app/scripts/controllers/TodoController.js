﻿firstApp.controller('todoController', function ($scope, todoService) {

    var _addTodo = function () {
        todoService.addTodo($scope.TodoItem).then(
            function () {
                _getTodoItemAndSetOnScope();
            },
            function () {
                alert("Error occured");
            });
    };

    var _deleteTodo = function (item) {
        todoService.deleteTodo(item).then(function () {
                _getTodoItemAndSetOnScope();
            });
    };

    var _getTodoItemAndSetOnScope = function () {
        todoService.getTodoItems().then(function (result) {
            $scope.todoItems = result;
        });
    };

    _getTodoItemAndSetOnScope();

    $scope.TodoItem = "";
    $scope.AddTodo = _addTodo;
    $scope.DeleteTodo = _deleteTodo;
});