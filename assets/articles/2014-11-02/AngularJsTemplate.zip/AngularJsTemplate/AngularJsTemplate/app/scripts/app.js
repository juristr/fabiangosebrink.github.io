﻿var firstApp = angular.module('firstApp', ['ngRoute', 'ngResource', 'ui.bootstrap']);

firstApp.config(function ($routeProvider) {

    $routeProvider

    	// home page
    	.when('/', {
    	    templateUrl: '../views/home.html',
    	    controller: 'homeController'
    	})

    	// todo
    	.when('/todo', {
    	    templateUrl: '../views/todo.html',
    	    controller: 'todoController'
    	});
}); 


