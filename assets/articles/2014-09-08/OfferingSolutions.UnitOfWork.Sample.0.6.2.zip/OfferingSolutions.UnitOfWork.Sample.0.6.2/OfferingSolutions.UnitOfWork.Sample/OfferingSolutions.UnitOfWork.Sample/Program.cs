﻿using OfferingSolutions.UnitOfWork.Sample.Context;
using OfferingSolutions.UnitOfWork.Sample.ExampleCustomRepository;
using OfferingSolutions.UnitOfWork.Sample.Models;
using OfferingSolutions.UoW.Structure.UnitOfWorkContext;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace OfferingSolutions.UnitOfWork.Sample
{
    public class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.InitializeDataBase();

            using (IOsUnitOfWorkContext unitOfWorkContext = new OsUnitOfWorkContext(new DatabaseContext()))
            {
                Person person = new Person() { Age = 28, Name = "Fabian" };

                //Adding a new Entity, for example "Person"
                unitOfWorkContext.Add(person);

                //Savechanges
                unitOfWorkContext.Save();

                // Get all Persons
                List<Person> allPersons = unitOfWorkContext.GetAll<Person>();

                // Get all Persons with the age of 35
                List<Person> allPersonsOnAge35 = unitOfWorkContext.GetAll<Person>(x => x.Age == 35);

                // Get all Persons with the age of 35 ordered by Name
                List<Person> allPersonsOnAge35Ordered = unitOfWorkContext.GetAll<Person>(x => x.Age == 35, orderBy: q => q.OrderBy(d => d.Name));

                // Get all Persons with the age of 35 ordered by Name and include its properties
                List<Person> allPersonsOnAge35OrderedAndWithSiblings = unitOfWorkContext.GetAll<Person>(
                    x => x.Age == 35,
                    orderBy: q => q.OrderBy(d => d.Name),
                    includeProperties: "Siblings");

                // Get all Persons and include its properties
                List<Person> allPersonsWithSiblings = unitOfWorkContext.GetAll<Person>(includeProperties: "Siblings");

                // Find a single Person with a specific name
                Person findBy = unitOfWorkContext.FindBy<Person>(x => x.Name == "Fabian");

                // Find a single Person with a specific name and include its siblings
                Person findByWithSiblings = unitOfWorkContext.FindBy<Person>(x => x.Name == "Fabian", includeProperties: "Siblings");

                // Find a person by id 
                unitOfWorkContext.FindSingle<Person>(6);

                //Update an existing person
                unitOfWorkContext.Update(person);

                //Add or Update a Person
                unitOfWorkContext.AddOrUpdate<Person>(person);

                //Deleting a Person by Id or by entity
                //unitOfWorkContext.Delete<Person>(6);
                unitOfWorkContext.Delete(person);
            }

            using (IPersonRepository personRepository = new PersonRepository(new DatabaseContext()))
            {
                Person person = new Person();

                //Access basic functions, which can be overwritten
                personRepository.Add(person);

                //Access extended functions
                personRepository.MyNewMethod(6);
            }

            using (IOsUnitOfWorkContext unitOfWorkContext = new OsUnitOfWorkContext(new DatabaseContext()))
            {
                List<Person> persons = unitOfWorkContext.GetAll<Person>();

                foreach (Person person in persons)
                {
                    Console.WriteLine(person.Name);
                }
            }

            Console.ReadLine();
        }

        private void InitializeDataBase()
        {
            Database.SetInitializer(new DropCreateDatabaseAlways<DatabaseContext>());

            DatabaseContext context = new DatabaseContext();
            context.Database.Initialize(false);
        }
    }
}
