﻿using System.Collections.Generic;

namespace OfferingSolutions.UnitOfWork.Sample.Models
{
    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public List<Sibling> Siblings { get; set; }
    }
}