﻿namespace OfferingSolutions.UnitOfWork.Sample.Models
{
    public class Thing
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}