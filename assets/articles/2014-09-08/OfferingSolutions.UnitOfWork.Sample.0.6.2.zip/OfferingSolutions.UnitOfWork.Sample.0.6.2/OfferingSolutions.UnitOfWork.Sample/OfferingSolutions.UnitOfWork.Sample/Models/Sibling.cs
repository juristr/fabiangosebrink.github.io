﻿namespace OfferingSolutions.UnitOfWork.Sample.Models
{
    public class Sibling
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}