﻿using OfferingSolutions.UnitOfWork.Sample.Context;
using OfferingSolutions.UnitOfWork.Sample.Models;
using OfferingSolutions.UoW.Structure.RepositoryContext;

namespace OfferingSolutions.UnitOfWork.Sample.ExampleCustomRepository
{
    public class PersonRepository : RepositoryContextImpl<Person>, IPersonRepository
    {
        public PersonRepository(DatabaseContext dbContext)
            : base(dbContext)
        {

        }

        public void MyNewMethod(int id)
        {
            //Do Something
        }

        public override void Add(Person toAdd)
        {
            MyAdditionalAddFunction();
            base.Add(toAdd);
        }

        private void MyAdditionalAddFunction()
        {
            //Do something else...
        }
    }
}
